classdef Channel < handle

    properties (Constant)
        speedOfLightInMetersPerSecond = 3e8
    end
    properties (Dependent)
        wavelengthInMeters
    end
    properties
        frequencyInHertz = -1
        transmitAntennaGain = 1
        receiveAntennaGain = 1
    end
    
    methods (Abstract)
        calculateGain(thisObject, distanceInMeters)
    end
    
    methods
        function newObject = Channel(frequencyInHertz)
            newObject.frequencyInHertz = frequencyInHertz;
        end
        function wavelength = get.wavelengthInMeters(thisObject)
            c = thisObject.speedOfLightInMetersPerSecond;
            f = thisObject.frequencyInHertz;
            
            lambda = c./f;
            
            wavelength = lambda;
        end
    end
    
end

