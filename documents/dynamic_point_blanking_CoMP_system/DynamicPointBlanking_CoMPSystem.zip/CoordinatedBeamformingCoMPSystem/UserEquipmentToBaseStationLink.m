classdef UserEquipmentToBaseStationLink < Link
    methods
        function newObject = UserEquipmentToBaseStationLink(channel)
            newObject = newObject@Link(channel);
        end
    end
end
